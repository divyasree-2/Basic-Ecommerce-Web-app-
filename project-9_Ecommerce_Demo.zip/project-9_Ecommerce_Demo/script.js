document.addEventListener("DOMContentLoaded", () => {
  const products = [
    { id: 1, name: "Product 1", price: 29.99 },
    { id: 2, name: "Product 2", price: 79.99 },
    { id: 3, name: "Product 3", price: 59.99 },
  ];
  const cart = [];

  // Grabbing all the requried Elements -->
  const product_list = document.getElementById("product-list");
  const cart_items = document.getElementById("cart-items");
  const empty_cart = document.getElementById("empty-cart");
  const cart_total = document.getElementById("cart-total");
  const total_price_display = document.getElementById("total-price");
  const checkout_btn = document.getElementById("checkout-btn");

  products.forEach((product) => {
    const product_div = document.createElement("div");
    product_div.classList.add("product");
    product_div.innerHTML = `
    <span>${product.name} - $${product.price.toFixed(2)}</span>
    <button data-id="${product.id}">Add to Cart</button>
    `;
    product_list.appendChild(product_div);
  });

  product_list.addEventListener("click", (e) => {
    if (e.target.tagName === "BUTTON") {
      const product_id = parseInt(e.target.getAttribute("data-id"));
      const product = products.find((p) => p.id == product_id);
      addToCart(product);
    }
  });

  function addToCart(product) {
    cart.push(product);
    renderCart();
  }

  function renderCart() {
    cart_items.innerHTML = ""
    let totalPrice = 0;

    if(cart.length > 0){
      empty_cart.classList.add('hidden')
      cart_total.classList.remove('hidden')
      cart.forEach((item, index) => {
        totalPrice += item.price
        const cartItem = document.createElement('div')
        cartItem.innerHTML = `
        ${item.name} - $${item.price.toFixed(2)}
        `
        cart_items.appendChild(cartItem)
        total_price_display.textContent = `${totalPrice.toFixed(2)}`
      })
    }else{
      empty_cart.classList.remove('hidden')
      total_price_display.textContent = `0.0`
    }
  }

  checkout_btn.addEventListener('click', () => {
    cart.length = 0
    alert("Checkout Successfully!")
    renderCart()
  })
});
